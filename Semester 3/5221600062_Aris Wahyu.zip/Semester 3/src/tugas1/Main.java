/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1;

/**
 *
 * @author ASUS
 */
public class Main {
    public static void main(String[] args) {
        Agent agent1 = new Agent();
        Agent agent2 = new Agent("Loid", 100);
        Player player1 = new Player();
        Player player2 = new Player(1, 180);
        
        agent1.Info();
        agent2.Info();
        player1.InfoPlayer();
        player2.InfoPlayer();
    }
}
