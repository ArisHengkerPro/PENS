package tugas1;

public class Player {
    private int direction, id, strength;
    
    public Player(){
        
    }
    
    public Player(int id, int direction){
        this.id = id;
        this.direction = direction;
    }
    
    public void AddStrength(int str){
        strength = str;
    }
    
    public void InfoPlayer(){
        System.out.print("Player Id   : " + id);
        System.out.println(" Direction   : " + direction);
    }
    
}
