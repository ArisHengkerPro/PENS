package tugas1;

public class Agent {

    private int pos_x, pos_y, health;
    private String nama;

    public Agent() {
        
    }
    
    public Agent(String nama, int health) {
        this.nama = nama;
        this.health = health;
    }
    
    public void SetPos(int x, int y){
        pos_x = x;
        pos_y = y;
    }
    
    public int GetPos(){
        return 0;
    }
    
    public void Info(){
        System.out.print("Name    : " + nama);
        System.out.println(" Health  : " + health);
    }
    
}
